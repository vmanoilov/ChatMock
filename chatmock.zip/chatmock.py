from __future__ import annotations

from chatmock.cli import main

if __name__ == "__main__":
    main()

